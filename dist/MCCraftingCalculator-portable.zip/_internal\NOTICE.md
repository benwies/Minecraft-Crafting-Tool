# MC Crafting Calculator — Notices

1) Code license
- The application source code is licensed under the MIT License (see LICENSE).

2) Third‑party assets not covered by the LICENSE
- Any Minecraft game textures, icons, or data (including recipe JSONs derived from game content or official data packs) are the property of Mojang Studios / Microsoft.
- Such assets, if present, are provided only for compatibility and are NOT licensed under this repository’s LICENSE. They remain subject to their respective copyrights and terms.
- If requested by the rights holder, these assets will be removed.

3) Trademarks
- “Minecraft” and related names are trademarks of Mojang Studios / Microsoft. This project is not affiliated with, endorsed by, or sponsored by Mojang Studios or Microsoft.
